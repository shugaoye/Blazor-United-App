﻿using Microsoft.Extensions.Configuration;

namespace $safeprojectname$;

public class ConfigurationFixture : IDisposable
{
	public Settings Settings { get; set; }

	public ConfigurationFixture() 
	{
		// Build a config object, using env vars and JSON providers.
		var config = new ConfigurationBuilder()
			.AddJsonFile("appsettings.json")
			.AddEnvironmentVariables()
			.Build();
		Settings = config.GetRequiredSection(typeof(ConfigurationFixture).Namespace).Get<Settings>();
	}

	public void Dispose() { }
}

[CollectionDefinition("Configuration collection")]
public class ConfigurationCollection : ICollectionFixture<ConfigurationFixture>
{
// This class has no code, and is never created. Its purpose is simply
// to be the place to apply [CollectionDefinition] and all the
// ICollectionFixture<> interfaces.
}