﻿using Bunit;
using $ext_safeprojectname$.Shared.Components;

namespace $safeprojectname$.Components
{
    public class SurveyPromptTests : TestContext
    {
        [Fact]
        public void Create_SurveyPrompt_Success() 
        {
            // Arrange
            string title = "How is Blazor working for you?";

            // Act
            var cut = RenderComponent<SurveyPrompt>(
                parameters => parameters.Add(p => p.Title, title));
            
            // Assert
            cut.Find("strong").TextContent.MarkupMatches(title);
        }
    }
}