using System.Diagnostics;
using $ext_safeprojectname$.Shared.OpenAPI;

namespace $safeprojectname$;

[Collection("Configuration collection")]
public class WeatherForecastTests
{
	private readonly Settings settings;


	public WeatherForecastTests(ConfigurationFixture config) 
    { 
        this.settings = config.Settings;
    }

    [Fact]
    public void Set_TemperatureC_Success()
    {
		// Arrange
		var data = new WeatherForecast
        {
            // Act
            TemperatureC = 1
        };

        // Assert
        Assert.Equal(1, data.TemperatureC);

        Debug.WriteLine("Set_TemperatureC_Success");
    }

    [Fact]
    public async Task Get_WeatherForecastData_SuccessAsync()
    {
		// Arrange
		ICollection<WeatherForecast>? forecasts;
	    AppServices appServices = new(settings.Url, new HttpClient());

		// Act
		forecasts = await appServices.WeatherForecastAsync();

		// Assert
		Assert.Equal(6, forecasts.Count);
	}
}