using Microsoft.AspNetCore.Mvc;
using $ext_safeprojectname$.Shared.Data;

namespace $safeprojectname$.Controllers;

/// <summary>
/// Provides WeatherForecast services.
/// </summary>
[ApiController]
[Route("[controller]")]
public class WeatherForecastController : ControllerBase
{
    private static readonly string[] Summaries = new[]
    {
    "Freezing", "Bracing", "Chilly", "Cool", "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching"
    };

    private readonly ILogger<WeatherForecastController> _logger;

    /// <summary>
    /// Constructor of WeatherForecast services.
    /// </summary>
    public WeatherForecastController(ILogger<WeatherForecastController> logger)
    {
        _logger = logger;
    }

    /// <summary>
    /// Returns a list of WeatherForecast.
    /// </summary>
    [HttpGet]
    public IEnumerable<WeatherForecast> Get()
    {
		_logger.LogDebug("Request new WeatherForecast info at {DT}", DateTime.Now.ToLongTimeString());

		return Enumerable.Range(1, 6).Select(index => new WeatherForecast
        {
            Date = DateTime.Now.AddDays(index),
            TemperatureC = Random.Shared.Next(-20, 55),
            Summary = Summaries[Random.Shared.Next(Summaries.Length)]
        })
        .ToArray();
    }
}