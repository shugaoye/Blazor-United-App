﻿using Microsoft.AspNetCore.Components.WebView.Maui;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using $ext_safeprojectname$.Shared;
using $ext_safeprojectname$.Shared.OpenAPI;
using System.Reflection;

namespace $safeprojectname$;

public static class MauiProgram
{
    public static MauiApp CreateMauiApp()
    {
        var builder = MauiApp.CreateBuilder();
        builder
            .UseMauiApp<App>()
            .ConfigureFonts(fonts =>
            {
                fonts.AddFont("OpenSans-Regular.ttf", "OpenSansRegular");
            });

		var a = Assembly.GetExecutingAssembly();
		using var stream = a.GetManifestResourceStream("$safeprojectname$.appsettings.json");

		builder.Configuration.AddConfiguration(new ConfigurationBuilder()
			.AddJsonStream(stream)
			.Build());

		builder.Services.AddMauiBlazorWebView();
#if DEBUG
		builder.Services.AddBlazorWebViewDeveloperTools();
        builder.Logging.AddDebug();
        builder.Logging.SetMinimumLevel(LogLevel.Debug);
#endif
        App.Settings = builder.Configuration.GetSection("$safeprojectname$").Get<Settings>();

		builder.Services.AddScoped(sp => new HttpClient { BaseAddress = new Uri(App.Settings.Url) });
		builder.Services.AddScoped(sp => new AppServices(App.Settings.Url, new HttpClient()));

		return builder.Build();
    }
}