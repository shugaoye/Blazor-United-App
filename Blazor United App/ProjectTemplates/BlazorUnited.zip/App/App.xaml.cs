﻿using $ext_safeprojectname$.Shared;

namespace $safeprojectname$;

public partial class App : Application
{
    public static Settings  Settings { get; set; }

	public App()
    {
        InitializeComponent();

        MainPage = new MainPage();
    }
}